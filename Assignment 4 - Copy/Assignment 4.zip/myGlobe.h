#include "GlobeVertices.h"
#include "GlobeNormals.h"
#include "GlobeColors.h"
#include "GlobeTextureMap.h"

char * myTextureBmp = "earthHQ.bmp";

